#include "gtest/gtest.h"
#include "simple_calc.h"

TEST(SimpleCalcTest, AddTest) {
    SimpleCalc calc;
    EXPECT_EQ(calc.add(10, 5), 15);
}

TEST(SimpleCalcTest, SubtractTest) {
    SimpleCalc calc;
    EXPECT_EQ(calc.subtract(10, 5), 5);
}

TEST(SimpleCalcTest, MultiplyTest) {
    SimpleCalc calc;
    EXPECT_EQ(calc.multiply(10, 5), 50);
}

TEST(SimpleCalcTest, DivideTest) {
    SimpleCalc calc;
    EXPECT_EQ(calc.divide(10, 5), 2);
}

TEST(SimpleCalcTest, DivideByZero) {
    SimpleCalc calc;
    EXPECT_THROW(calc.divide(10, 0), std::invalid_argument);
}