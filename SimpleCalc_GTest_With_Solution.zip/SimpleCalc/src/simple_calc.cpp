#include "simple_calc.h"
#include <stdexcept>

int SimpleCalc::add(int a, int b) {
    return a + b;
}

int SimpleCalc::subtract(int a, int b) {
    return a - b;
}

int SimpleCalc::multiply(int a, int b) {
    return a * b;
}

int SimpleCalc::divide(int a, int b) {
    if (b == 0)
        throw std::invalid_argument("Division by zero");
    return a / b;
}