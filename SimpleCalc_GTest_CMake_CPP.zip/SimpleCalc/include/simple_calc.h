#ifndef SIMPLE_CALC_H
#define SIMPLE_CALC_H

class SimpleCalc {
public:
    int add(int a, int b);
    int subtract(int a, int b);
    int multiply(int a, int b);
    int divide(int a, int b); // throws exception on divide-by-zero
};

#endif // SIMPLE_CALC_H